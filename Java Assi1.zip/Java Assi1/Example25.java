//Java Program to demonstrate the use of Integer.parseInt() method  
//for converting Octal to Decimal number  
public class Example25{  
public static void main(String args[]){  
//Declaring an octal number  
String octalString="10";  
//Converting octal number into decimal  
int decimal=Integer.parseInt(octalString,8);  
//Printing converted decimal number  
System.out.println(decimal);  
}}  //1*8^0+0*8^1=8