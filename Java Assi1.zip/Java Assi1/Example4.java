public class Example4 {

 public static void main(String[] args) {
   int w = -5 + 8 * 6;
   int x = (55 + 9) % 9;
   int y = 20 + (-3 * 5 / 8);
   int z = 5 + 15 / 3 * 2 - 8 % 3;

   System.out.print(w + "\n" + x + "\n" + y + "\n" + z);
  }
}
//43
//1
//19
//13