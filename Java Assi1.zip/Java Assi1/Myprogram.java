import java.util.Scanner;
public class Myprogram
{
  public static void main(String argd[])
{
  System.out.println("Enter a number");

Scanner kb = new Scanner(System.in);
int n = kb.nextInt();

int i;
for(i=2;i<n;i++)
if(n%i==0)
break;
if(i==n)
System.out.println("Number is prime");
else
System.out.println("Number is not prime");
}
}