public class Add
{
  public static void main(String args[])
{
  int a=10;
  int b=20;
  int s;
s= a*b;

System.out.print("sum of " +a+" and "+b+" is "+s);
}
}
    