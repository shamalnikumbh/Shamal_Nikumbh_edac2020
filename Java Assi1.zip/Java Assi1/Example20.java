public class Example20{  
public static void main(String args[]){  

System.out.println(Integer.toHexString(15));  

}}  //output f
