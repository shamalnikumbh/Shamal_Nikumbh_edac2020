//Java Program to demonstrate the use of Integer.toOctalString() method  
public class Example21{  
public static void main(String args[]){  
//Using the predefined Integer.toOctalString() method  
//to convert decimal value into octal   
System.out.println(Integer.toOctalString(15));  
}}  //17
