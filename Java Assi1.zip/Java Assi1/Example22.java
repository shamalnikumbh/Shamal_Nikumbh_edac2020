public class Example22{  
public static void main(String args[]){  
String binaryString="100";  
int decimal=Integer.parseInt(binaryString,2);  
System.out.println(decimal);  
}} //     4 2 1
    //     1 0 0 = 4