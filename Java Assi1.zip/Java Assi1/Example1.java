public class Example1{
 
 public static void main(String[] args) {
  System.out.println("Hello\nAlexandra Abramov"); \\  \n- take cursor new line
 }
 
}
//Hello
//Alexandra Abramov