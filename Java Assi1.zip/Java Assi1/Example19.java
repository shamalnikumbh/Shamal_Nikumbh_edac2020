public class Example19{  
public static void main(String args[]){  
System.out.println(Integer.toBinaryString(5));  
  
}}  //output 101
    //8 4 2 1 
    //   1 0 1
