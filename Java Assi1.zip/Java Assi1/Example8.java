
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("Enter number of rows: "); // takes input from user
 
        int rows = sc.nextInt();
         
        for (int i= 0; i<= rows; i++)
        {
            for (int j=1; j<=rows-i; j++)
            {
                System.out.print(" ");
            }
            for (int k=0;k<=i;k++)
            {
                System.out.print("j");
            } 
                System.out.println("");
        }
        int j = 0;
		for (int k=0;k<=j;k++)
        {
            System.out.print("a");
        } 
            System.out.println("");
    }
    int j = 1;{
	for (int k=0;k<=k;k++)
    {
        System.out.print("j");
    } 
        System.out.println("");
}
 
    }
//output
j
 jj
jjj
a