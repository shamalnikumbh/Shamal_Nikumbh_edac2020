 import java.util.Scanner; //user se input lena hai
public class Prime
{
  public static void main(String[]args)
{
   System.out.println("Enter a number");

  Scanner kb=new Scanner(System.in);//it creates scanner object
  int n=kb.nextInt();  //ye function return karega vo no. user enter kar raha hai
  int i;
  for(i=2;i<n;i++)
  if(n%i==0)
break;
if(i==n)
 System.out.println("No is prime");
else
System.out.println("No is not prime");
}
}

